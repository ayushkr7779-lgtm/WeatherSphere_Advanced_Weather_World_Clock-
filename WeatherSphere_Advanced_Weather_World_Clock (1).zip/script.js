const $ = id => document.getElementById(id);
let chart;

const weatherCodes = {
  0:["Clear sky","☀️"],1:["Mainly clear","🌤️"],2:["Partly cloudy","⛅"],3:["Overcast","☁️"],
  45:["Fog","🌫️"],48:["Rime fog","🌫️"],51:["Light drizzle","🌦️"],53:["Drizzle","🌦️"],
 55:["Heavy drizzle","🌧️"],61:["Light rain","🌦️"],63:["Rain","🌧️"],65:["Heavy rain","🌧️"],
71:["Light snow","🌨️"],73:["Snow","🌨️"],75:["Heavy snow","❄️"],80:["Rain showers","🌦️"],
81:["Rain showers","🌧️"],82:["Heavy showers","⛈️"],95:["Thunderstorm","⛈️"],96:["Thunderstorm + hail","⛈️"],99:["Thunderstorm + hail","⛈️"]
};

const cities = [
  ["🇮🇳","Delhi","Asia/Kolkata"],["🇬🇧","London","Europe/London"],["🇺🇸","New York","America/New_York"],
  ["🇦🇪","Dubai","Asia/Dubai"],["🇯🇵","Tokyo","Asia/Tokyo"],["🇦🇺","Sydney","Australia/Sydney"],
  ["🇸🇬","Singapore","Asia/Singapore"],["🇫🇷","Paris","Europe/Paris"],["🇩🇪","Berlin","Europe/Berlin"],
  ["🇨🇦","Toronto","America/Toronto"],["🇧🇷","São Paulo","America/Sao_Paulo"],["🇿🇦","Johannesburg","Africa/Johannesburg"]
];

async function geocode(name){
  const url=`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=en&format=json`;
  const r=await fetch(url); if(!r.ok) throw new Error("Geocoding failed");
  const d=await r.json(); if(!d.results?.length) throw new Error("City not found");
  return d.results[0];
}

async function weather(lat,lon){
  const params=new URLSearchParams({
    latitude:lat,longitude:lon,timezone:"auto",
    current:"temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m",
    hourly:"temperature_2m,precipitation_probability,weather_code",
    daily:"weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max",
    forecast_days:"7"
  });
  const r=await fetch(`https://api.open-meteo.com/v1/forecast?${params}`);
  if(!r.ok) throw new Error("Weather request failed"); return r.json();
}

function fmtTime(iso, tz){
  return new Intl.DateTimeFormat("en-IN",{hour:"numeric",minute:"2-digit",hour12:true,timeZone:tz}).format(new Date(iso));
}
function compass(deg){
  const dirs=["N","NE","E","SE","S","SW","W","NW"]; return dirs[Math.round(deg/45)%8];
}
function reveal(){["weatherPanel","forecastSection","chartSection"].forEach(x=>$(x).classList.remove("hidden"))}

async function loadCity(name){
  $("status").textContent=`Loading weather for ${name}...`;
  try{
    const g=await geocode(name), d=await weather(g.latitude,g.longitude), tz=d.timezone;
    const c=d.current, w=weatherCodes[c.weather_code]||["Unknown","🌡️"];
    $("cityName").textContent=`${g.name}, ${g.country_code||""}`;
    $("localDate").textContent=new Intl.DateTimeFormat("en-IN",{dateStyle:"full",timeZone:tz}).format(new Date());
    $("weatherIcon").textContent=w[1]; $("temp").textContent=Math.round(c.temperature_2m);
    $("condition").textContent=w[0]; $("feels").textContent=`Feels like ${Math.round(c.apparent_temperature)}°C`;
    $("humidity").textContent=`${c.relative_humidity_2m}%`; $("wind").textContent=`${Math.round(c.wind_speed_10m)} km/h`;
    $("pressure").textContent=`${Math.round(c.pressure_msl)} hPa`; $("visibility").textContent="—";
    $("precip").textContent=`${c.precipitation} mm`; $("windDir").textContent=`${compass(c.wind_direction_10m)} (${Math.round(c.wind_direction_10m)}°)`;
    $("sunrise").textContent=fmtTime(d.daily.sunrise[0],tz); $("sunset").textContent=fmtTime(d.daily.sunset[0],tz);
    $("uv").textContent=d.daily.uv_index_max[0].toFixed(1); $("coords").textContent=`${g.latitude.toFixed(2)}, ${g.longitude.toFixed(2)}`;
    renderForecast(d,tz); renderChart(d,tz); reveal();
    $("status").textContent=`Updated for ${g.name} • Time zone: ${tz}`;
    $("cityInput").value=g.name;
  }catch(e){$("status").textContent="❌ "+e.message}
}

function renderForecast(d,tz){
  $("forecast").innerHTML=d.daily.time.map((date,i)=>{
    const w=weatherCodes[d.daily.weather_code[i]]||["Unknown","🌡️"];
    const day=new Intl.DateTimeFormat("en-IN",{weekday:"short",timeZone:tz}).format(new Date(date+"T12:00:00"));
    return `<div class="day"><div class="day-name">${day}</div><div class="day-icon">${w[1]}</div><small>${w[0]}</small><div class="day-temp">${Math.round(d.daily.temperature_2m_max[i])}° / ${Math.round(d.daily.temperature_2m_min[i])}°</div></div>`;
  }).join("");
}

function renderChart(d,tz){
  const now=new Date(), labels=[], values=[];
  for(let i=0;i<Math.min(24,d.hourly.time.length);i++){
    const t=new Date(d.hourly.time[i]); if(t<now) continue;
    labels.push(new Intl.DateTimeFormat("en-IN",{hour:"numeric",hour12:true,timeZone:tz}).format(t));
    values.push(d.hourly.temperature_2m[i]);
  }
  if(chart) chart.destroy();
  chart=new Chart($("tempChart"),{type:"line",data:{labels,datasets:[{label:"Temperature °C",data:values,tension:.35,fill:true}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{title:{display:true,text:"°C"}}}}});
}

function renderClocks(){
  $("clocks").innerHTML=cities.map(([flag,name,tz])=>`<div class="clock"><div class="flag">${flag}</div><div class="place">${name}</div><div class="time" data-tz="${tz}">--:--</div><div class="zone">${tz}</div></div>`).join("");
  tickClocks();
}
function tickClocks(){
  document.querySelectorAll(".clock .time").forEach(el=>{
    el.textContent=new Intl.DateTimeFormat("en-IN",{hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true,timeZone:el.dataset.tz}).format(new Date());
  });
}
$("searchBtn").onclick=()=>{const v=$("cityInput").value.trim(); if(v) loadCity(v)};
$("cityInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("searchBtn").click()});
$("locationBtn").onclick=()=>navigator.geolocation.getCurrentPosition(p=>loadCity(`${p.coords.latitude},${p.coords.longitude}`),()=>{$("status").textContent="Location permission denied. Search a city instead."});
document.querySelectorAll("[data-city]").forEach(b=>b.onclick=()=>loadCity(b.dataset.city));
$("themeBtn").onclick=()=>{document.body.classList.toggle("dark");$("themeBtn").textContent=document.body.classList.contains("dark")?"☀️":"🌙";localStorage.theme=document.body.classList.contains("dark")?"dark":"light"};
if(localStorage.theme==="dark"){document.body.classList.add("dark");$("themeBtn").textContent="☀️"}
renderClocks(); setInterval(tickClocks,1000); loadCity("Delhi");
