# WeatherSphere — Advanced Weather & World Clock

A beginner-friendly advanced web development project using:
- HTML5
- CSS3
- JavaScript
- Fetch API
- Geolocation API
- Open-Meteo weather + geocoding APIs
- Chart.js
- JavaScript Intl DateTimeFormat for live world clocks

## How to run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Internet is required because weather data and Chart.js are loaded online.
4. Search any city, use My Location, or click a popular city.

## Main features
- Current weather
- 7-day forecast
- Next 24-hour temperature chart
- Humidity, wind, pressure, precipitation, sunrise/sunset, UV
- City search
- Geolocation
- Live clocks for multiple world cities
- Dark/light mode
- Responsive mobile layout

## Notes
The project uses Open-Meteo, so no API key is required for this demo.
